import { Component } from '@angular/core';

@Component({
  selector: 'app-tenant-orders',
  imports: [],
  templateUrl: './tenant-orders.component.html',
  styleUrl: './tenant-orders.component.scss'
})
export class TenantOrdersComponent {

}
